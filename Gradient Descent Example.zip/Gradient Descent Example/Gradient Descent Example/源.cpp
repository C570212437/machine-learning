#include<stdio.h>
#include<string.h>
#include<stdlib.h>

void main()
{
	void read(double data[100][2]);
	double compute_error(double b, double k, double data[100][2]);
	double *compute_dradient(double b, double k, double data[100][2], double rate);
	double *runner(double start_b, double start_k, double data[100][2], double rate, int time);
	double data[100][2];
	double b,k,error;
	int i,j;
	read(data);
	b = 0.0889365199374;
	k = 1.47774408519;
	printf("Initial b: %lf, initial k: %lf\n",b,k);
	printf("Initial error: %lf\n\n",compute_error(b,k,data));
	b = *runner(b, k, data, 0.0001,10000);
	k = *(runner(b, k, data, 0.0001,10000)+1);
	error = compute_error(b,k,data);
	printf("b: %lf, k: %lf\n",b,k);
	printf("error: %lf\n",error);
	system("pause");
}

void read(double data[100][2])
{
	FILE *fp = NULL;
	char *line, *record;
	char buffer[1024];
	int i,j;
	if((fp = fopen("data.txt", "at+"))!=NULL)
	{
		fseek(fp,0,SEEK_SET);
		i = 0;
		while((line = fgets(buffer,1024,fp))!=NULL)
		{
			j = 0;
			record = strtok(line,",");
			while(record!=NULL)
			{
				if(j==0)
				{
					data[i][0] = atof(record);
					j++;
				}
				else
				{
					data[i][1] = atof(record);
					j=0;
				}
				record = strtok(NULL,",");
			}
			i++;
		}
	}
}

double compute_error(double b, double k, double data[100][2])
{
	double error = 0;
	int i,j;
	for(i=0;i<100;i++)
	{
		error += (data[i][1] - (k*data[i][0]+b))*(data[i][1] - (k*data[i][0]+b))/2;
	}
	return error;
}

double *compute_dradient(double b, double k, double data[100][2], double rate)
{
	double gradient_b = 0;
	double gradient_k = 0;
	double result[2] = {0,0};
	double x,y;
	int i;
	for(i=0;i<100;i++)
	{
		x = data[i][0];
		y = data[i][1];
		gradient_b += ((k*x+b)-y)/100;
		gradient_k += ((k*x+b)-y)*x/100;
	}
	double b_new = b - rate*gradient_b;
	double k_new = k - rate*gradient_k;
	result[0] = b_new;
	result[1] = k_new;
	return result;
}

double *runner(double start_b, double start_k, double data[100][2], double rate, int time)
{
	double b = start_b;
	double k = start_k;
	double result[2];
	int t;
	for(t=0;t<time;t++)
	{
		b = *compute_dradient(b,k,data,rate);
		k = *(compute_dradient(b,k,data,rate)+1);
	}
	result[0] = b;
	result[1] = k;
	return result;
}

